#! /usr/bin/env python

from Engine import game_window
game_window.main()
